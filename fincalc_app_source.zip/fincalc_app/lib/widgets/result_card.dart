import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ResultCard extends StatelessWidget {
  final String title;
  final double primaryAmount;
  final String currency;
  final Map<String, dynamic> secondaryDetails;

  const ResultCard({
    super.key,
    required this.title,
    required this.primaryAmount,
    this.currency = 'د.ل',
    this.secondaryDetails = const {},
  });

  @override
  Widget build(BuildContext context) {
    final formatter = NumberFormat('#,##0.00', 'ar');
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: Theme.of(context).primaryColor.withOpacity(0.05),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).primaryColor,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Text(
                  formatter.format(primaryAmount),
                  style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                ),
                const SizedBox(width: 8),
                Text(
                  currency,
                  style: TextStyle(fontSize: 18, color: Colors.grey[700]),
                ),
              ],
            ),
            if (secondaryDetails.isNotEmpty) ...[
              const Divider(height: 24),
              ...secondaryDetails.entries.map((e) {
                String valStr = e.value is double
                    ? '${formatter.format(e.value)} $currency'
                    : e.value.toString();
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(e.key, style: const TextStyle(color: Colors.black87)),
                      Text(valStr, style: const TextStyle(fontWeight: FontWeight.w600)),
                    ],
                  ),
                );
              }),
            ]
          ],
        ),
      ),
    );
  }
}
