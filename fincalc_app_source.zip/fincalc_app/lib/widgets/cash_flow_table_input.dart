import 'package:flutter/material.dart';
import '../models/cash_flow_entry.dart';

class CashFlowTableInput extends StatefulWidget {
  final List<CashFlowEntry> entries;
  final VoidCallback onChanged;

  const CashFlowTableInput({
    super.key,
    required this.entries,
    required this.onChanged,
  });

  @override
  State<CashFlowTableInput> createState() => _CashFlowTableInputState();
}

class _CashFlowTableInputState extends State<CashFlowTableInput> {
  void _addEntry() {
    setState(() {
      int nextYear = widget.entries.isEmpty ? 1 : widget.entries.last.year + 1;
      widget.entries.add(CashFlowEntry(year: nextYear, amount: 1000.0));
    });
    widget.onChanged();
  }

  void _removeEntry(int index) {
    setState(() {
      widget.entries.removeAt(index);
    });
    widget.onChanged();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'جدول التدفقات النقدية:',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            ElevatedButton.icon(
              onPressed: _addEntry,
              icon: const Icon(Icons.add, size: 18),
              label: const Text('إضافة سنة'),
            )
          ],
        ),
        const SizedBox(height: 8),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: widget.entries.length,
          itemBuilder: (context, index) {
            final entry = widget.entries[index];
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 4),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Row(
                  children: [
                    Text('السنة ${entry.year}:', style: const TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(width: 16),
                    Expanded(
                      child: TextFormField(
                        initialValue: entry.amount.toString(),
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          hintText: 'المبلغ',
                          isDense: true,
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (val) {
                          double? v = double.tryParse(val);
                          if (v != null) {
                            entry.amount = v;
                            widget.onChanged();
                          }
                        },
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _removeEntry(index),
                    )
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
