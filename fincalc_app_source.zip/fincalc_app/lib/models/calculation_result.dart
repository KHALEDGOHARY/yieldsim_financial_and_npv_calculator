class CalculationResult {
  final double primaryResult;
  final String primaryLabel;
  final Map<String, dynamic> details;

  CalculationResult({
    required this.primaryResult,
    required this.primaryLabel,
    this.details = const {},
  });
}
