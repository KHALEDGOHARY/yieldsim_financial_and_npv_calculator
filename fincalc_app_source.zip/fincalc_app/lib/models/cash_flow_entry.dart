class CashFlowEntry {
  final int year;
  double amount;

  CashFlowEntry({required this.year, required this.amount});

  Map<String, dynamic> toJson() => {'year': year, 'amount': amount};
  factory CashFlowEntry.fromJson(Map<String, dynamic> json) =>
      CashFlowEntry(year: json['year'], amount: (json['amount'] as num).toDouble());
}
