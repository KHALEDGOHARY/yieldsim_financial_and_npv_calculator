import 'dart:math';
import '../models/cash_flow_entry.dart';

class FVCashFlowsResult {
  final double totalFutureValue;
  final double totalNominalCashFlows;
  final List<double> compoundedValues;

  FVCashFlowsResult({
    required this.totalFutureValue,
    required this.totalNominalCashFlows,
    required this.compoundedValues,
  });
}

FVCashFlowsResult calculateFVCashFlows({
  required List<CashFlowEntry> cashFlows,
  required double interestRatePercent,
  required int targetYear,
}) {
  double r = interestRatePercent / 100.0;
  double totalFV = 0.0;
  double totalNominal = 0.0;
  List<double> compounded = [];

  for (var cf in cashFlows) {
    totalNominal += cf.amount;
    int compoundingYears = targetYear - cf.year;
    if (compoundingYears >= 0) {
      double fv = cf.amount * pow(1 + r, compoundingYears);
      totalFV += fv;
      compounded.add(fv);
    } else {
      compounded.add(cf.amount);
    }
  }

  return FVCashFlowsResult(
    totalFutureValue: totalFV,
    totalNominalCashFlows: totalNominal,
    compoundedValues: compounded,
  );
}
