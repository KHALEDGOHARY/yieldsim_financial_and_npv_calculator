import 'dart:math';

class CompoundInterestResult {
  final double simpleInterest;
  final double simpleTotal;
  final double compoundInterest;
  final double compoundTotal;
  final double difference;

  CompoundInterestResult({
    required this.simpleInterest,
    required this.simpleTotal,
    required this.compoundInterest,
    required this.compoundTotal,
    required this.difference,
  });
}

CompoundInterestResult calculateCompoundInterest({
  required double principal,
  required double annualRatePercent,
  required double years,
  required int compoundingFrequency, // 1 for annual, 12 for monthly, etc.
}) {
  double rate = annualRatePercent / 100.0;
  
  // Simple Interest: I = P * r * t
  double simpleInt = principal * rate * years;
  double simpleTot = principal + simpleInt;

  // Compound Interest: A = P * (1 + r/n)^(n*t)
  double compoundTot;
  if (compoundingFrequency > 0) {
    compoundTot = principal * pow(1 + (rate / compoundingFrequency), compoundingFrequency * years);
  } else {
    compoundTot = principal;
  }
  double compoundInt = compoundTot - principal;

  return CompoundInterestResult(
    simpleInterest: simpleInt,
    simpleTotal: simpleTot,
    compoundInterest: compoundInt,
    compoundTotal: compoundTot,
    difference: compoundTot - simpleTot,
  );
}
