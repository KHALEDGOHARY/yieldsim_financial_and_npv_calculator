import 'dart:math';

class MonthlySimulationPoint {
  final int month;
  final double startingBalance;
  final double deposit;
  final double interestEarned;
  final double withdrawal;
  final double endingBalance;
  final double totalInvested;

  MonthlySimulationPoint({
    required this.month,
    required this.startingBalance,
    required this.deposit,
    required this.interestEarned,
    required this.withdrawal,
    required this.endingBalance,
    required this.totalInvested,
  });
}

class InvestmentFundResult {
  final double finalBalance;
  final double totalPrincipalDeposited;
  final double totalInterestEarned;
  final double totalWithdrawals;
  final List<MonthlySimulationPoint> schedule;

  InvestmentFundResult({
    required this.finalBalance,
    required this.totalPrincipalDeposited,
    required this.totalInterestEarned,
    required this.totalWithdrawals,
    required this.schedule,
  });
}

enum FundMode { reinvest, periodicWithdrawal }

InvestmentFundResult simulateInvestmentFund({
  required double initialDeposit,
  required double monthlyDeposit,
  required double annualReturnPercent,
  required int years,
  required FundMode mode,
  double monthlyWithdrawalAmount = 0.0,
}) {
  int totalMonths = years * 12;
  double monthlyRate = (annualReturnPercent / 100.0) / 12.0;

  double currentBalance = initialDeposit;
  double totalInvested = initialDeposit;
  double totalInterest = 0.0;
  double totalWithdrawn = 0.0;

  List<MonthlySimulationPoint> schedule = [];

  for (int m = 1; m <= totalMonths; m++) {
    double startBal = currentBalance;
    // Add periodic deposit at start of month
    double currentDeposit = (m == 1) ? initialDeposit + monthlyDeposit : monthlyDeposit;
    if (m > 1) {
      totalInvested += monthlyDeposit;
    } else {
      totalInvested = initialDeposit + monthlyDeposit;
    }
    
    double baseForInterest = startBal + monthlyDeposit;
    double interestThisMonth = baseForInterest * monthlyRate;
    totalInterest += interestThisMonth;

    double endBal = baseForInterest + interestThisMonth;
    double withdrawalThisMonth = 0.0;

    if (mode == FundMode.periodicWithdrawal) {
      withdrawalThisMonth = monthlyWithdrawalAmount;
      if (endBal >= withdrawalThisMonth) {
        endBal -= withdrawalThisMonth;
      } else {
        withdrawalThisMonth = endBal;
        endBal = 0.0;
      }
      totalWithdrawn += withdrawalThisMonth;
    }

    currentBalance = endBal;

    schedule.add(MonthlySimulationPoint(
      month: m,
      startingBalance: startBal,
      deposit: (m == 1) ? initialDeposit + monthlyDeposit : monthlyDeposit,
      interestEarned: interestThisMonth,
      withdrawal: withdrawalThisMonth,
      endingBalance: currentBalance,
      totalInvested: totalInvested,
    ));
  }

  return InvestmentFundResult(
    finalBalance: currentBalance,
    totalPrincipalDeposited: totalInvested,
    totalInterestEarned: totalInterest,
    totalWithdrawals: totalWithdrawn,
    schedule: schedule,
  );
}
