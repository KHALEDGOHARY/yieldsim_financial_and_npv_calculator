import 'dart:math';

class PresentValueResult {
  final double presentValue;
  final double totalFutureNominal;
  final double discountAmount;

  PresentValueResult({
    required this.presentValue,
    required this.totalFutureNominal,
    required this.discountAmount,
  });
}

PresentValueResult calculatePresentValue({
  required double futureAmount,
  required double annualDiscountRatePercent,
  required double years,
  double periodicPayment = 0.0, // PMT if annuity
}) {
  double r = annualDiscountRatePercent / 100.0;

  // Single Sum PV = FV / (1 + r)^t
  double pvSingle = futureAmount / pow(1 + r, years);

  // Annuity PV = PMT * [1 - (1+r)^-t] / r
  double pvAnnuity = 0.0;
  if (periodicPayment > 0 && r > 0) {
    pvAnnuity = periodicPayment * (1 - pow(1 + r, -years)) / r;
  } else if (periodicPayment > 0 && r == 0) {
    pvAnnuity = periodicPayment * years;
  }

  double totalPV = pvSingle + pvAnnuity;
  double totalNominal = futureAmount + (periodicPayment * years);

  return PresentValueResult(
    presentValue: totalPV,
    totalFutureNominal: totalNominal,
    discountAmount: totalNominal - totalPV,
  );
}
