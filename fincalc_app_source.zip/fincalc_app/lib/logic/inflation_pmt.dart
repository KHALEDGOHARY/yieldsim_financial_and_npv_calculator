import 'dart:math';

class InflationPmtResult {
  final double realInterestRate;
  final double nominalPmt;
  final double adjustedFirstYearPmt;
  final List<double> yearlyPaymentSchedule;

  InflationPmtResult({
    required this.realInterestRate,
    required this.nominalPmt,
    required this.adjustedFirstYearPmt,
    required this.yearlyPaymentSchedule,
  });
}

InflationPmtResult calculateInflationAdjustedPmt({
  required double targetFutureAmount,
  required double nominalAnnualRatePercent,
  required double inflationRatePercent,
  required int years,
  required bool isEscalating, // true = escalating annually by inflation, false = fixed real PMT
}) {
  double i = nominalAnnualRatePercent / 100.0;
  double e = inflationRatePercent / 100.0;

  // Fisher Equation: Real Rate r = (1 + i) / (1 + e) - 1
  double realRate = ((1 + i) / (1 + e)) - 1;

  double nominalPmt = 0.0;
  List<double> schedule = [];

  if (!isEscalating) {
    // Fixed payment in inflated terms using Fisher real rate
    if (realRate != 0) {
      // Annuity formula for PMT given FV
      nominalPmt = targetFutureAmount * realRate / (pow(1 + realRate, years) - 1);
    } else {
      nominalPmt = targetFutureAmount / years;
    }
    for (int y = 1; y <= years; y++) {
      schedule.add(nominalPmt);
    }
  } else {
    // Escalating payment starting at base and growing by inflation each year
    double basePmt;
    if (i != 0) {
      basePmt = targetFutureAmount * i / (pow(1 + i, years) - 1);
    } else {
      basePmt = targetFutureAmount / years;
    }
    for (int y = 1; y <= years; y++) {
      schedule.add(basePmt * pow(1 + e, y - 1));
    }
    nominalPmt = basePmt;
  }

  return InflationPmtResult(
    realInterestRate: realRate * 100.0,
    nominalPmt: nominalPmt,
    adjustedFirstYearPmt: schedule.isNotEmpty ? schedule.first : nominalPmt,
    yearlyPaymentSchedule: schedule,
  );
}
