import 'dart:math';
import '../models/cash_flow_entry.dart';

class NPVResult {
  final double npv;
  final double initialInvestment;
  final double presentValueInflows;
  final double profitabilityIndex;
  final bool isViable;

  NPVResult({
    required this.npv,
    required this.initialInvestment,
    required this.presentValueInflows,
    required this.profitabilityIndex,
    required this.isViable,
  });
}

NPVResult calculateNPV({
  required double initialInvestment,
  required List<CashFlowEntry> cashFlows,
  required double discountRatePercent,
}) {
  double r = discountRatePercent / 100.0;
  double pvInflows = 0.0;

  for (var cf in cashFlows) {
    if (cf.year > 0) {
      pvInflows += cf.amount / pow(1 + r, cf.year);
    }
  }

  double npv = pvInflows - initialInvestment;
  double pi = initialInvestment > 0 ? (pvInflows / initialInvestment) : 0.0;

  return NPVResult(
    npv: npv,
    initialInvestment: initialInvestment,
    presentValueInflows: pvInflows,
    profitabilityIndex: pi,
    isViable: npv >= 0,
  );
}
