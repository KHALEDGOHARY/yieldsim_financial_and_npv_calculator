import 'package:flutter/material.dart';
import '../logic/compound_interest.dart';
import '../widgets/labeled_input_field.dart';
import '../widgets/result_card.dart';

class CompoundInterestScreen extends StatefulWidget {
  const CompoundInterestScreen({super.key});

  @override
  State<CompoundInterestScreen> createState() => _CompoundInterestScreenState();
}

class _CompoundInterestScreenState extends State<CompoundInterestScreen> {
  final _formKey = GlobalKey<FormState>();
  final _principalCtrl = TextEditingController(text: '10000');
  final _rateCtrl = TextEditingController(text: '5');
  final _yearsCtrl = TextEditingController(text: '3');
  CompoundInterestResult? _result;

  void _calculate() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _result = calculateCompoundInterest(
          principal: double.parse(_principalCtrl.text),
          annualRatePercent: double.parse(_rateCtrl.text),
          years: double.parse(_yearsCtrl.text),
          compoundingFrequency: 1,
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الفائدة البسيطة والمركبة')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              LabeledInputField(label: 'المبلغ الأصلي (رأس المال)', controller: _principalCtrl),
              LabeledInputField(label: 'معدل الفائدة السنوي (%)', controller: _rateCtrl),
              LabeledInputField(label: 'المدة (بالسنوات)', controller: _yearsCtrl),
              const SizedBox(height: 16),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(50),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                onPressed: _calculate,
                child: const Text('احسب', style: TextStyle(fontSize: 18)),
              ),
              const SizedBox(height: 20),
              if (_result != null)
                ResultCard(
                  title: 'إجمالي الجملة بالفائدة المركبة',
                  primaryAmount: _result!.compoundTotal,
                  secondaryDetails: {
                    'فائدة مركب صافية': _result!.compoundInterest,
                    'جملة الفائدة البسيطة': _result!.simpleTotal,
                    'فائدة بسيطة صافية': _result!.simpleInterest,
                    'الفرق لصالح المركبة': _result!.difference,
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}
