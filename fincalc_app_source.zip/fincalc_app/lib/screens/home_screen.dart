import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  final List<Map<String, dynamic>> calculators = const [
    {
      'title': 'الفائدة البسيطة والمركبة',
      'icon': Icons.show_chart,
      'route': '/compound_interest',
      'subtitle': 'مقارنة عوائد الاستثمار البسيط والمركب'
    },
    {
      'title': 'صندوق الاستثمار',
      'icon': Icons.account_balance_wallet,
      'route': '/investment_fund',
      'subtitle': 'محاكاة شهرية مع إعادة الاستثمار أو السحب الدوري'
    },
    {
      'title': 'قسط تعويض التضخم',
      'icon': Icons.trending_up,
      'route': '/inflation_pmt',
      'subtitle': 'معادلة فيشر وحساب القسط لمواجهة التضخم'
    },
    {
      'title': 'القيمة الحالية (PV)',
      'icon': Icons.history_toggle_off,
      'route': '/present_value',
      'subtitle': 'خصم المبالغ والدفعات المستقبلية'
    },
    {
      'title': 'صافي القيمة المستقبلية',
      'icon': Icons.auto_graph,
      'route': '/fv_cashflows',
      'subtitle': 'تجميع التدفقات غير المتساوية برأس مال مركب'
    },
    {
      'title': 'صافي القيمة الحالية (NPV)',
      'icon': Icons.assessment,
      'route': '/npv',
      'subtitle': 'تقييم جدوى المشاريع والاستثمارات'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الحاسبة المالية المتطورة'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: ListView.builder(
          itemCount: calculators.length,
          itemBuilder: (context, index) {
            final calc = calculators[index];
            return Card(
              elevation: 2,
              margin: const EdgeInsets.symmetric(vertical: 8),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Theme.of(context).primaryColor.withOpacity(0.1),
                  child: Icon(calc['icon'], color: Theme.of(context).primaryColor),
                ),
                title: Text(calc['title'], style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(calc['subtitle']),
                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                onTap: () => Navigator.pushNamed(context, calc['route']),
              ),
            );
          },
        ),
      ),
    );
  }
}
