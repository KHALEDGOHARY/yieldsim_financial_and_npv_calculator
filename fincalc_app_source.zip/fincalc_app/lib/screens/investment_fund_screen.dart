import 'package:flutter/material.dart';
import '../logic/investment_fund.dart';
import '../widgets/labeled_input_field.dart';
import '../widgets/result_card.dart';

class InvestmentFundScreen extends StatefulWidget {
  const InvestmentFundScreen({super.key});

  @override
  State<InvestmentFundScreen> createState() => _InvestmentFundScreenState();
}

class _InvestmentFundScreenState extends State<InvestmentFundScreen> {
  final _formKey = GlobalKey<FormState>();
  final _initialCtrl = TextEditingController(text: '1000');
  final _monthlyCtrl = TextEditingController(text: '100');
  final _rateCtrl = TextEditingController(text: '6');
  final _yearsCtrl = TextEditingController(text: '5');
  final _withdrawalCtrl = TextEditingController(text: '50');

  FundMode _mode = FundMode.reinvest;
  InvestmentFundResult? _result;

  void _calculate() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _result = simulateInvestmentFund(
          initialDeposit: double.parse(_initialCtrl.text),
          monthlyDeposit: double.parse(_monthlyCtrl.text),
          annualReturnPercent: double.parse(_rateCtrl.text),
          years: int.parse(_yearsCtrl.text),
          mode: _mode,
          monthlyWithdrawalAmount: double.tryParse(_withdrawalCtrl.text) ?? 0.0,
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('صندوق الاستثمار')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              SegmentedButton<FundMode>(
                segments: const [
                  ButtonSegment(value: FundMode.reinvest, label: Text('إعادة استثمار')),
                  ButtonSegment(value: FundMode.periodicWithdrawal, label: Text('سحب دوري')),
                ],
                selected: {_mode},
                onSelectionChanged: (set) {
                  setState(() {
                    _mode = set.first;
                  });
                },
              ),
              const SizedBox(height: 12),
              LabeledInputField(label: 'الدفعة الأولى المقدمة', controller: _initialCtrl),
              LabeledInputField(label: 'الدفعة الشهرية', controller: _monthlyCtrl),
              LabeledInputField(label: 'معدل العائد السنوي (%)', controller: _rateCtrl),
              LabeledInputField(label: 'المدة (بالسنوات)', controller: _yearsCtrl),
              if (_mode == FundMode.periodicWithdrawal)
                LabeledInputField(label: 'مبلغ السحب الشهري', controller: _withdrawalCtrl),
              const SizedBox(height: 16),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(50),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                onPressed: _calculate,
                child: const Text('احسب المحاكاة', style: TextStyle(fontSize: 18)),
              ),
              const SizedBox(height: 20),
              if (_result != null)
                ResultCard(
                  title: _mode == FundMode.reinvest
                      ? 'الرصيد النهائي للصندوق'
                      : 'الرصيد المتبقي بالصندوق',
                  primaryAmount: _result!.finalBalance,
                  secondaryDetails: {
                    'إجمالي المبالغ المودعة': _result!.totalPrincipalDeposited,
                    'إجمالي الأرباح المحققة': _result!.totalInterestEarned,
                    if (_mode == FundMode.periodicWithdrawal)
                      'إجمالي المبالغ المسحوبة': _result!.totalWithdrawals,
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}
