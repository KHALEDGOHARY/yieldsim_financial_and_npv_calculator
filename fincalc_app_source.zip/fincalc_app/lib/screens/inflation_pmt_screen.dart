import 'package:flutter/material.dart';
import '../logic/inflation_pmt.dart';
import '../widgets/labeled_input_field.dart';
import '../widgets/result_card.dart';

class InflationPmtScreen extends StatefulWidget {
  const InflationPmtScreen({super.key});

  @override
  State<InflationPmtScreen> createState() => _InflationPmtScreenState();
}

class _InflationPmtScreenState extends State<InflationPmtScreen> {
  final _formKey = GlobalKey<FormState>();
  final _targetCtrl = TextEditingController(text: '100000');
  final _rateCtrl = TextEditingController(text: '8');
  final _inflationCtrl = TextEditingController(text: '3');
  final _yearsCtrl = TextEditingController(text: '5');
  bool _isEscalating = false;

  InflationPmtResult? _result;

  void _calculate() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _result = calculateInflationAdjustedPmt(
          targetFutureAmount: double.parse(_targetCtrl.text),
          nominalAnnualRatePercent: double.parse(_rateCtrl.text),
          inflationRatePercent: double.parse(_inflationCtrl.text),
          years: int.parse(_yearsCtrl.text),
          isEscalating: _isEscalating,
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('قسط تعويض التضخم')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('نوع القسط:'),
                  FilterChip(
                    label: Text(_isEscalating ? 'متصاعد سنوياً' : 'ثابت حقيقي'),
                    selected: _isEscalating,
                    onSelected: (val) {
                      setState(() {
                        _isEscalating = val;
                      });
                    },
                  ),
                ],
              ),
              LabeledInputField(label: 'المبلغ المستهدف مستقبلاً', controller: _targetCtrl),
              LabeledInputField(label: 'المعدل الاسمي السنوي (%)', controller: _rateCtrl),
              LabeledInputField(label: 'معدل التضخم السنوي (%)', controller: _inflationCtrl),
              LabeledInputField(label: 'المدة (سنوات)', controller: _yearsCtrl),
              const SizedBox(height: 16),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(50),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                onPressed: _calculate,
                child: const Text('احسب القسط اللازم', style: TextStyle(fontSize: 18)),
              ),
              const SizedBox(height: 20),
              if (_result != null)
                ResultCard(
                  title: 'القسط السنوي المطلوب',
                  primaryAmount: _result!.nominalPmt,
                  secondaryDetails: {
                    'معدل العائد الحقيقي (معادلة فيشر)': '${_result!.realInterestRate.toStringAsFixed(2)}%',
                    'قسط السنة الأولى': _result!.adjustedFirstYearPmt,
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}
