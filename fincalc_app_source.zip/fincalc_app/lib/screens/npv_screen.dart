import 'package:flutter/material.dart';
import '../logic/npv.dart';
import '../models/cash_flow_entry.dart';
import '../widgets/cash_flow_table_input.dart';
import '../widgets/labeled_input_field.dart';
import '../widgets/result_card.dart';

class NPVScreen extends StatefulWidget {
  const NPVScreen({super.key});

  @override
  State<NPVScreen> createState() => _NPVScreenState();
}

class _NPVScreenState extends State<NPVScreen> {
  final _investmentCtrl = TextEditingController(text: '5000');
  final _rateCtrl = TextEditingController(text: '10');
  List<CashFlowEntry> entries = [
    CashFlowEntry(year: 1, amount: 3000),
    CashFlowEntry(year: 2, amount: 4000),
  ];

  NPVResult? _result;

  void _calculate() {
    setState(() {
      _result = calculateNPV(
        initialInvestment: double.tryParse(_investmentCtrl.text) ?? 0.0,
        cashFlows: entries,
        discountRatePercent: double.tryParse(_rateCtrl.text) ?? 0.0,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('صافي القيمة الحالية (NPV)')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            LabeledInputField(label: 'تكلفة الاستثمار المبدئي (رأس المال)', controller: _investmentCtrl),
            LabeledInputField(label: 'معدل الخصم / التكلفة (%)', controller: _rateCtrl),
            const SizedBox(height: 12),
            CashFlowTableInput(entries: entries, onChanged: () => setState(() {})),
            const SizedBox(height: 16),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onPressed: _calculate,
              child: const Text('تقييم المشروع (NPV)', style: TextStyle(fontSize: 18)),
            ),
            const SizedBox(height: 20),
            if (_result != null)
              ResultCard(
                title: _result!.isViable ? 'المشروع مجدٍ اقتصادياً (NPV > 0)' : 'المشروع غير مجدٍ',
                primaryAmount: _result!.npv,
                secondaryDetails: {
                  'القيمة الحالية للتدفقات الداخلة': _result!.presentValueInflows,
                  'مؤشر الربحية (PI)': _result!.profitabilityIndex.toStringAsFixed(2),
                  'القرار الاستثماري': _result!.isViable ? 'قبول المشروع' : 'رفض المشروع',
                },
              ),
          ],
        ),
      ),
    );
  }
}
