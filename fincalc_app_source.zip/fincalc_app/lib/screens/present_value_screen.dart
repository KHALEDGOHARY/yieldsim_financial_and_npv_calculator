import 'package:flutter/material.dart';
import '../logic/present_value.dart';
import '../widgets/labeled_input_field.dart';
import '../widgets/result_card.dart';

class PresentValueScreen extends StatefulWidget {
  const PresentValueScreen({super.key});

  @override
  State<PresentValueScreen> createState() => _PresentValueScreenState();
}

class _PresentValueScreenState extends State<PresentValueScreen> {
  final _formKey = GlobalKey<FormState>();
  final _futureCtrl = TextEditingController(text: '10000');
  final _rateCtrl = TextEditingController(text: '5');
  final _yearsCtrl = TextEditingController(text: '2');
  final _pmtCtrl = TextEditingController(text: '0');

  PresentValueResult? _result;

  void _calculate() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _result = calculatePresentValue(
          futureAmount: double.parse(_futureCtrl.text),
          annualDiscountRatePercent: double.parse(_rateCtrl.text),
          years: double.parse(_yearsCtrl.text),
          periodicPayment: double.tryParse(_pmtCtrl.text) ?? 0.0,
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('القيمة الحالية (PV)')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              LabeledInputField(label: 'المبلغ المستقبلي (FV)', controller: _futureCtrl),
              LabeledInputField(label: 'معدل الخصم السنوي (%)', controller: _rateCtrl),
              LabeledInputField(label: 'عدد السنوات', controller: _yearsCtrl),
              LabeledInputField(label: 'دفعة دورية اختيارية (PMT)', controller: _pmtCtrl),
              const SizedBox(height: 16),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(50),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                onPressed: _calculate,
                child: const Text('احسب القيمة الحالية', style: TextStyle(fontSize: 18)),
              ),
              const SizedBox(height: 20),
              if (_result != null)
                ResultCard(
                  title: 'إجمالي القيمة الحالية (PV)',
                  primaryAmount: _result!.presentValue,
                  secondaryDetails: {
                    'إجمالي التدفق المستقبلي الاسمي': _result!.totalFutureNominal,
                    'قيمة الخصم المطلقة': _result!.discountAmount,
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}
