import 'package:flutter/material.dart';
import '../logic/fv_cashflows.dart';
import '../models/cash_flow_entry.dart';
import '../widgets/cash_flow_table_input.dart';
import '../widgets/labeled_input_field.dart';
import '../widgets/result_card.dart';

class FVCashFlowsScreen extends StatefulWidget {
  const FVCashFlowsScreen({super.key});

  @override
  State<FVCashFlowsScreen> createState() => _FVCashFlowsScreenState();
}

class _FVCashFlowsScreenState extends State<FVCashFlowsScreen> {
  final _rateCtrl = TextEditingController(text: '5');
  final _targetYearCtrl = TextEditingController(text: '3');
  List<CashFlowEntry> entries = [
    CashFlowEntry(year: 1, amount: 1000),
    CashFlowEntry(year: 2, amount: 2000),
  ];

  FVCashFlowsResult? _result;

  void _calculate() {
    setState(() {
      _result = calculateFVCashFlows(
        cashFlows: entries,
        interestRatePercent: double.tryParse(_rateCtrl.text) ?? 0.0,
        targetYear: int.tryParse(_targetYearCtrl.text) ?? 3,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('FV للتدفقات النقدية')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            LabeledInputField(label: 'معدل فائدة إعادة الاستثمار (%)', controller: _rateCtrl),
            LabeledInputField(label: 'السنة المستهدفة للتجميع', controller: _targetYearCtrl),
            const SizedBox(height: 12),
            CashFlowTableInput(entries: entries, onChanged: () => setState(() {})),
            const SizedBox(height: 16),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onPressed: _calculate,
              child: const Text('احسب القيمة المستقبلية', style: TextStyle(fontSize: 18)),
            ),
            const SizedBox(height: 20),
            if (_result != null)
              ResultCard(
                title: 'صافي القيمة المستقبلية للتدفقات',
                primaryAmount: _result!.totalFutureValue,
                secondaryDetails: {
                  'مجموع التدفقات الاسمية': _result!.totalNominalCashFlows,
                  'الأرباح المركبة المحققة': _result!.totalFutureValue - _result!.totalNominalCashFlows,
                },
              ),
          ],
        ),
      ),
    );
  }
}
