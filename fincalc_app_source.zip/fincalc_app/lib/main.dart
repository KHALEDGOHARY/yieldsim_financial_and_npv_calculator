import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'screens/home_screen.dart';
import 'screens/compound_interest_screen.dart';
import 'screens/investment_fund_screen.dart';
import 'screens/inflation_pmt_screen.dart';
import 'screens/present_value_screen.dart';
import 'screens/fv_cashflows_screen.dart';
import 'screens/npv_screen.dart';

void main() {
  runApp(const FinCalcApp());
}

class FinCalcApp extends StatelessWidget {
  const FinCalcApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'الحاسبة المالية المتطورة',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar', ''),
      supportedLocales: const [Locale('ar', '')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        primarySwatch: Colors.teal,
        primaryColor: const Color(0xFF006A60),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF006A60)),
        fontFamily: 'Roboto',
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const HomeScreen(),
        '/compound_interest': (context) => const CompoundInterestScreen(),
        '/investment_fund': (context) => const InvestmentFundScreen(),
        '/inflation_pmt': (context) => const InflationPmtScreen(),
        '/present_value': (context) => const PresentValueScreen(),
        '/fv_cashflows': (context) => const FVCashFlowsScreen(),
        '/npv': (context) => const NPVScreen(),
      },
    );
  }
}
