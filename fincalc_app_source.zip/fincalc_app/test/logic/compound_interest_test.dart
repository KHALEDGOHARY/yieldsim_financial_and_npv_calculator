import 'package:flutter_test/flutter_test.dart';
import 'package:fincalc_app/logic/compound_interest.dart';

void main() {
  test('Compound Interest Calculation Test', () {
    final result = calculateCompoundInterest(
      principal: 10000,
      annualRatePercent: 5,
      years: 3,
      compoundingFrequency: 1,
    );

    expect(result.simpleInterest, closeTo(1500, 0.01));
    expect(result.simpleTotal, closeTo(11500, 0.01));
    expect(result.compoundTotal, closeTo(11576.25, 0.5));
    expect(result.compoundInterest, closeTo(1576.25, 0.5));
  });
}
