import 'package:flutter_test/flutter_test.dart';
import 'package:fincalc_app/logic/present_value.dart';

void main() {
  test('Present Value Single Sum Test', () {
    final result = calculatePresentValue(
      futureAmount: 10000,
      annualDiscountRatePercent: 5,
      years: 2,
    );

    // PV = 10000 / (1.05)^2 = 9070.29
    expect(result.presentValue, closeTo(9070.29, 0.5));
  });
}
