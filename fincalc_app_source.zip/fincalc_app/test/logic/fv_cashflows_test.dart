import 'package:flutter_test/flutter_test.dart';
import 'package:fincalc_app/logic/fv_cashflows.dart';
import 'package:fincalc_app/models/cash_flow_entry.dart';

void main() {
  test('FV Cashflows Test', () {
    final entries = [
      CashFlowEntry(year: 1, amount: 1000),
      CashFlowEntry(year: 2, amount: 2000),
    ];
    final result = calculateFVCashFlows(
      cashFlows: entries,
      interestRatePercent: 5,
      targetYear: 3,
    );

    // Year 1: 1000 * 1.05^2 = 1102.5
    // Year 2: 2000 * 1.05^1 = 2100.0
    // Total FV = 3202.5
    expect(result.totalFutureValue, closeTo(3202.5, 0.5));
  });
}
