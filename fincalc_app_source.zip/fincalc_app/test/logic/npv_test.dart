import 'package:flutter_test/flutter_test.dart';
import 'package:fincalc_app/logic/npv.dart';
import 'package:fincalc_app/models/cash_flow_entry.dart';

void main() {
  test('NPV Calculation Test', () {
    final entries = [
      CashFlowEntry(year: 1, amount: 3000),
      CashFlowEntry(year: 2, amount: 4000),
    ];
    final result = calculateNPV(
      initialInvestment: 5000,
      cashFlows: entries,
      discountRatePercent: 10,
    );

    // PV Year 1 = 3000 / 1.1 = 2727.27
    // PV Year 2 = 4000 / 1.21 = 3305.78
    // Total PV = 6033.05
    // NPV = 6033.05 - 5000 = 1033.05
    expect(result.npv, closeTo(1033.05, 0.5));
    expect(result.isViable, isTrue);
  });
}
