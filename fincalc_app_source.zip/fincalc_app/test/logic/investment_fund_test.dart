import 'package:flutter_test/flutter_test.dart';
import 'package:fincalc_app/logic/investment_fund.dart';

void main() {
  test('Investment Fund Reinvestment Test', () {
    final result = simulateInvestmentFund(
      initialDeposit: 1000,
      monthlyDeposit: 100,
      annualReturnPercent: 6,
      years: 1,
      mode: FundMode.reinvest,
    );

    expect(result.schedule.length, equals(12));
    expect(result.totalPrincipalDeposited, closeTo(2200, 0.1));
    expect(result.finalBalance, greaterThan(2200));
  });
}
