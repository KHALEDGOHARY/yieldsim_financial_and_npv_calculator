import 'package:flutter_test/flutter_test.dart';
import 'package:fincalc_app/logic/inflation_pmt.dart';

void main() {
  test('Inflation Adjusted PMT Fisher Equation Test', () {
    final result = calculateInflationAdjustedPmt(
      targetFutureAmount: 100000,
      nominalAnnualRatePercent: 8,
      inflationRatePercent: 3,
      years: 5,
      isEscalating: false,
    );

    // Fisher real rate: (1.08 / 1.03) - 1 = ~4.854%
    expect(result.realInterestRate, closeTo(4.854, 0.01));
    expect(result.nominalPmt, greaterThan(0));
  });
}
